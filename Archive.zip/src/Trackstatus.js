import Box from "@mui/material/Box";
import React, { useEffect, useState } from "react";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import StepContent from "@mui/material/StepContent";
import axios from "axios";

import { useParams, withRouter } from "react-router";
import Typography from "@mui/material/Typography";
import { Loyalty } from "@mui/icons-material";

export default function Trackstaus() {
  const [filteredata, Setfilteredata] = useState([]);
  const [copystate,Setcopystate] = useState('Copy Url');
  const params = useParams();
  const steps = [
    {
      pnrid: 12345678,
      location: "chennai",
      via: "Bus",
      address: `
        WEST MAMBALAM BRANCH                                                                     
        N. SAIRAMAN,
        30/1, Sampangi Reddy Street,
        West Mambalam, Chennai - 600 033.`,
      destination: `       
         WEST MAMBALAM BRANCH                                                                     
        N. SAIRAMAN,
        30/1, Sampangi Reddy Street,
        West Mambalam, Chennai - 600 033.`,
    },
    {
      pnrid: 12345678,
      location: "mumbai",
      via: "Bus",
      address: `
        WEST MAMBALAM BRANCH                                                                     
        N. SAIRAMAN,
        30/1, Sampangi Reddy Street,
        West Mambalam, Chennai - 600 033.`,
    },
    {
      pnrid: 12345678,
      location: "kashmir",
      via: "Bus",
      address: `
        WEST MAMBALAM BRANCH                                                                     
        N. SAIRAMAN,
        30/1, Sampangi Reddy Street,
        West Mambalam, Chennai - 600 033.`,
    },
  ];


  function formatDate(dateString) {
    // Create a Date object from the string
    const date = new Date(dateString);
  
    // Get the day of the week (0-6, where 0 is Sunday)
    const dayOfWeek = date.getDay();
  
    // Array of day names
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  
    // Get the formatted day name (e.g., "Tuesday")
    const formattedDay = dayNames[dayOfWeek];
  
    // Get the date (day of the month)
    const dateOfMonth = date.getDate();
  
    // Get the month (0-11, where 0 is January)
    const month = date.getMonth();
  
    // Array of month names
    const monthNames = ["January", "February", "March", "April", "May", "June",
                       "July", "August", "September", "October", "November", "December"];  
  
    // Get the formatted month name (e.g., "March")
    const formattedMonth = monthNames[month];
  
    // Return the formatted string
    return `${formattedDay}, ${dateOfMonth} ${formattedMonth}`;
  }

  const fetchdata = async (id)=>{
    const result=  await axios.get(`http://localhost:8500/trackid/${id}`);
    Setfilteredata(result.data);

  }
  useEffect(() => {
   fetchdata(params.uid);
  }, []);

  return (
    
    <div className="statuscontainer">
      
      <div className="trackingdetails">
        <div className="tracks">
          <div className="track-head ">
            <p className="statusheading"> Order Tracking</p>
            {filteredata[filteredata.length-1]?.delivery_status=="Picked Order"?(
            <div className="deliverybox">
            <img width={50} src="https://cdn-icons-png.flaticon.com/512/756/756940.png" alt=""></img>
            <p className="deliverystatustext">{filteredata[filteredata.length-1]?.delivery_status}</p>
            </div>):""}

            {filteredata[filteredata.length-1]?.delivery_status=="On the Way"?(
            <div className="deliverybox">
            <img width={50} src="https://cdn-icons-png.flaticon.com/512/7541/7541708.png" alt=""></img>
            <p className="deliverystatustext">{filteredata[filteredata.length-1]?.delivery_status}</p>
            </div>):""}

            {filteredata[filteredata.length-1]?.delivery_status=="Delivered"?(
            <div className="deliverybox">
            <img width={50} src="https://cdn-icons-png.flaticon.com/512/9198/9198208.png" alt=""></img>
            <p className="deliverystatustext">{filteredata[filteredata.length-1]?.delivery_status}</p>
            </div>):""}

          </div>
          {filteredata.length > 0 ? (
            <div>
              <div className="step">
                <Stepper activeStep={filteredata.length - 1} orientation="vertical" >
                  {filteredata.map((step, index) => (
                    <Step key={step.unique_id}>

                      {step.cityname === filteredata[0].destination ? <StepLabel>
                        <div className="flexall">
                       <div>
                        {formatDate(step.currentdate)}</div> 
                        <div>
                        {index==filteredata.length-1 ? `Your Package is in ${step.cityname}`:`package has left ${step.cityname}`} 
                        </div>
                        </div>
                      

                      
                      </StepLabel> : <StepLabel> {step.cityname}</StepLabel>}
                      <StepContent>via - {step.transportname}<Typography>{step.currentlocation}</Typography>
                      <Box sx={{ mb: 2 }}></Box>
                      </StepContent>
                    </Step>
                  ))}
                </Stepper>
              </div>
              <div className="sh-flex">
                <img src="https://cdn-icons-png.flaticon.com/512/3178/3178943.png" alt="" width={40}></img>
                <p className="bolder">Shipping Details</p>
              </div>
              <div className="shippingdetails">
                <p className="shipingdetailheader">{filteredata[0].destination}</p>
                <p className="shippingaddress">
                  {filteredata[0].destinationaddress}
                </p>
              </div>
              <div className="wd-100 asa">

              <button className="button-38 " onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                Setcopystate('copied');
              
              }} role="button">{copystate} </button>
              </div>
             
            </div>
          )
          :
          (<p style={{textAlign:'center'}}>No Details Found for the Given Id</p>)

        
        }
          
        </div>
      </div>
    </div>
  );
}
