import './App.css';
import { Link } from "react-router-dom";


function App() {



  return (
    <div className="App">
      <div style={{ display: 'flex',flexDirection:'column', alignItems: 'center', justifyContent: 'center', gap: 10, height: '100%',flexWrap:'wrap' }}>
        <div className='grid'>
        <Link to="/track">
          <button>Check Tracking Status</button>
          </Link>
        </div>
        <div className='grid'>
        <Link to="/updatetrack">
        <button >Add Tracking Status</button>
        </Link>
    
        </div>
      </div>
    </div>
  );
}

export default App;
