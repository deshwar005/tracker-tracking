import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { Link } from "react-router-dom";

export default function CheckTrackingStatus() {
  const [uid, setUid] = useState("");
  String.prototype.isNumber = function(){return /^\d+$/.test(this);}

  return (
    <div className="centerdiv">
      <div className="sx-style">
        <p className="dfont">Track Your Parcel</p>

        <p style={{textAlign:'center',fontSize:"14px",fontWeight:
      "600"}}>
          Enter Tracking Number For Delivery Information
        </p>
        <TextField
          id="outlined-basic"
          placeholder="ex: 17282902020029"
          value={uid}
          onChange={(event) => {
            setUid(event.target.value);
          }}
          variant="outlined"
        />
        

          <Button  className="nocolor" variant="contained" disabled={(uid && uid.isNumber())?false:true}>
          <Link className="btn-search" to={`/trackid/${uid}` }>
          Track
          </Link>
           
            
          </Button>
        
      </div>
    </div>
  );
}
