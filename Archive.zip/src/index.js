import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';
import { StyledEngineProvider } from '@mui/material/styles';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import CheckTrackingStatus from './CheckTrackingStatus';
import AddTrackingStatus from './AddTrackingStatus';
import Trackstaus from './Trackstatus';


const root = createRoot(document.getElementById('root'));
root.render(
  <StyledEngineProvider injectFirst>
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} /> {/* Use App component as the root element */}
        <Route path="/track" element={<CheckTrackingStatus />} />
        <Route path="/trackid/:uid" element={<Trackstaus />} />
        <Route path="/updatetrack" element={<AddTrackingStatus />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
  </StyledEngineProvider>
);
