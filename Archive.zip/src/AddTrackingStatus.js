import React, { useState } from 'react';
import Button from "@mui/material/Button";
import TextField from '@mui/material/TextField';
import axios from 'axios';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';

export default function AddTrackingStatus() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [success, setSuccess] = useState(false);
  const [failure, setFailure] = useState(false);
  const [user, setUser] = useState({
    user_id:"no id"
  });
  const [transport, setTransport] = useState('Bus');
  const [deliverystatus, setdeliverystatus] = useState('Picked Order');

  const [sid, setsid] = useState('');
  const [currentcity, setcurrentcity] = useState('');
  const [currentcityaddress, setcurrentcityaddress] = useState('');
  const [toaddress, settoaddress] = useState('');
  const [toaddresscity, settoaddresscity] = useState('');
  const [ confirmation,Setconfirmation] = useState(true);


  const validateUser = () => {
    const userdetails = {
      username: username,
      password: password
    };

    const url = 'http://localhost:8500/login';
    axios.post(url, userdetails)
      .then(res => {
        console.log(res);
        if (res.data && res.data[0]?.user_id) {
          setSuccess(true);
          setFailure(false);
          setUser(res.data[0]);
        } else {
          setFailure(true);
          setSuccess(false);

        }
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };

  const updateorder = ()=>{
    const orderdetails = {
      sid: sid,
      transportname: transport,
      delivery_status: deliverystatus,
      cityname: currentcity,
      currentlocation: currentcityaddress,
      destination: toaddress,
      destinationaddress: toaddresscity,
    };


    const url = 'http://localhost:8500/updatestatus';
    axios.post(url, orderdetails)
      .then(res => {
        console.log(res);
        if(res.status==200){
          Setconfirmation(false);
        }
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }

  return (
    <div className='centerdiv'>
      {user.user_id =="no id" ? (
        <div className='sx-style'>
          {success && <Alert severity="success">Login Success redirecting..</Alert>}
          {failure && <Alert severity="error">Wrong Password</Alert>}

          <TextField
            value={username}
            onChange={(event) => {
              setUsername(event.target.value);
            }}
            id="demo-helper-text-misaligned"
            label="User Name"
          />
          <TextField
            value={password}
            onChange={(event) => {
              setPassword(event.target.value);
            }}
            id="demo-helper-text-misaligned"
            label="Password"
          />
          <Button className="btn-search" variant="contained" onClick={validateUser}>Enter</Button>
        </div>
      ) : (



        (confirmation ? (
        <div className='sx-style'>

        <TextField
        onChange={(event)=>{
          setsid(event.target.value);
        }}
        value={sid}
        label="Sid"
      />

<Select
        labelId="demo-select-small-label"
        id="demo-select-small"
        value={deliverystatus}
        label="delivery status"
        onChange={(event)=>{
          setdeliverystatus(event.target.value);
        }}
      >
        <MenuItem value="Picked Order">Picked Order</MenuItem>
        <MenuItem value="On the Way">On the Way</MenuItem>
        <MenuItem value="Delivered">Delivered</MenuItem>
      </Select>

      <Select
        labelId="demo-select-small-label"
        id="demo-select-small"
        value={transport}
        label="transportname"
        onChange={(event)=>{
          setTransport(event.target.value);
        }}
      >
        <MenuItem value="Bus">Bus</MenuItem>
        <MenuItem value="train">Train</MenuItem>
        <MenuItem value="flight">Flight</MenuItem>
      </Select>

<TextField
        value={currentcity}
        onChange={(event) => {
          setcurrentcity(event.target.value);
        }}
        id="demo-helper-text-misaligned"
        label="Current City"
      />

<TextField
        value={currentcityaddress}
        onChange={(event) => {
          setcurrentcityaddress(event.target.value);
        }}
        id="demo-helper-text-misaligned"
        label="Current city address"
      />

      <TextField
        value={toaddress}
        onChange={(event) => {
          settoaddress(event.target.value);
        }}
        id="demo-helper-text-misaligned"
        label="To address"
      />

<TextField
        value={toaddresscity}
        onChange={(event) => {
          settoaddresscity(event.target.value);
        }}
        id="demo-helper-text-misaligned"
        label="To address city"
      />
          <Button className="btn-search" variant="contained" onClick={updateorder} >Update Order Status</Button>

       </div>
        ):(
          <div style={{display:'flex',flexDirection:'column',gap:5,alignItems:'center',background:'white',padding:"20px 20px",borderRadius:'10px'}}>
            <img src='https://cdn-icons-png.flaticon.com/512/5610/5610944.png' width={35} height={35}></img>
            <p style={{fontSize:18,fontWeight:600}}>Order Updated Successfully</p>
          </div>
        ))
      )
      
      
      
      
      
      
      }
    </div>
  );
}
